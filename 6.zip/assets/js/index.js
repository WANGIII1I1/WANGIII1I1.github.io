/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var list;
var kcnumber;
$(function(){
    
 
    $(".btnSpan").click(function(){
		var e = $(this).attr("title");
		$(":radio").val([e]);
    })
    
})

///获取商品
function getgoodslist(tid){
    
    var ii = layer.load(2, {shade:[0.1,'#fff']});
    $.ajax({
            type : "POST",
            url : "ajax.php?act=getgoods&r="+getrandnumber(),
            data : {"tid":tid},
            dataType : 'json',
            success : function(data) {
                    layer.close(ii);
                    if(data.code == 1){
                        if(data.number > 0){
                             list = data.goodslist;
                             var option = "";
                             for(var i=0;i<list.length;i++){
                                 var goods = list[i];
                                 option = option + "<option value='"+goods.id+"' "+(option==""?"selected":"")+">"+goods.name+"</option>";
                             }
                             $("#goodsshow").html(option);
                             getgoodsmsg();
                        }else{
                              $("#goodsshow").html("<option value='-1'>无商品</option>");
                           $("#goodsinfo ").html("");
                            $("#goodsprice").text("0");
                            $("#goodskc").text(0);
                            kcnumber=0;
                             layer.msg("当前分类下面暂时没有商品");
                        }
                    }else{
                        list = null;
                            layer.msg(data.msg);
                            return false;
                    }
            },
            error:function(data){
                     layer.close(ii);
                      list = null;
                    layer.msg('系统错误！');
                    return false;
                    }
    })
}

//获取商品详细参数
function getgoodsmsg(){
    kcnumber=0;
    var gid = $("#goodsshow option:selected").val();
     for(var i=0;i<list.length;i++){
        var goods = list[i];
        if(goods.id != gid)    continue;
        if(goods.id == gid){
         
            $("#goodsinfo ").html(goods.info);
            $("#goodsprice").text(goods.price);
            $("#goodskc").text(goods.kccount);
            kcnumber = goods.kccount;
            $("#number").val(1);
        }
     }
}
function getrandnumber(){
      var timestamp =Date.parse(new Date());
      return timestamp;
}
function gettradeno(){
    var timestamp =Date.parse(new Date());
    var rand = Math.floor(Math.random()*(99999-99+1)+99);
    var randnumber = timestamp+""+rand;
    $.cookie('tradeno',randnumber);
    return randnumber;
}

//+
function numstepUp(){
    var number = parseInt($("#number").val());
    if(kcnumber>number){
        number++;
        $("#number").val(number);
    }else{
        layer.tips('亲,当前商品库存不足~', '#number_xz',{tips: [2, '#0FA6D8'],  tipsMore: false, time:1500  });
    }
    
}
//-
function numstepDown(){
    var number = parseInt($("#number").val());
    if(number >1){
         number--;
         $("#number").val(number);
    }else{
        layer.tips('亲,不能再少了~', '#number_xz',{tips: [2, '#0FA6D8'],  tipsMore: false, time:1500  });
    }
   
}
//检测选择数量是否合法
function checknum(){
    var number = parseInt($("#number").val());
    if(kcnumber<number){
        $("#number").val(kcnumber);
    }
    if(number <= 0){
        $("#number").val(1);
    }
}

function submit_orders(){
    var tradeno = gettradeno();
    var tid = $("#goodstype option:selected").val();
    var gid = $("#goodsshow option:selected").val();
    var gname = $("#goodsshow option:selected").text();
    var price = $("#goodsprice").text();
    var goodskc = $("#goodskc").text();
    var number = parseInt($("#number").val());
    var type = $("input:radio[name='type']:checked").val();//付款方式 
    var payfs = $("input:radio[name='type']:checked").attr("title");//付款方式2
    var qq = $("#qq").val();
    var allprice = (price*number).toFixed(2);
    if(gid <= 0){
        layer.tips('哎呀,该商品无法下单~~', '#submit_btn', {
            tips: [1, '#3595CC'],
            time: 1500
          });
          return;
    }
    if(qq=="" || isNaN(qq) || qq.length <5){
        layer.tips('亲,要输入正确的QQ号码哦~~', '#qq', {
            tips: [2, '#3595CC'],
            time: 1500
          });
          return;
    }
    if(kcnumber!=goodskc){
        layer.tips('哎呀,商品获取异常,请刷新页面重新下单~~', '#submit_btn', {
            tips: [1, '#3595CC'],
            time: 1500
          });
          return;
    }
    if(goodskc < 1 || number > goodskc){
        layer.tips('商品库存不足,无法购买！', '#submit_btn', {
            tips: [1, '#3595CC'],
            time: 2000
          });
          return;
    }
    if(payfs == undefined || type == undefined || payfs=="undefined" || type == "undefined"){
        layer.tips('亲,选择一个支付方式哦！', '#pay_type', {
            tips: [1, '#3595CC'],
            time: 2000
          });
          return;
    }
   
    var html = "<span style='color:#000'>"
                +"订单编号："+tradeno
                +"<br>商品名称："+gname
                +"<br>商品单价："+price+"￥"
                +"<br>购买数量："+number
                +"<br>联系QQ："+qq
                +"<br>支付方式："+payfs
                +"<br>应付款：<font style='font-size:18px' color=red>"+allprice+"</font>￥"
                +"</span>";       
    var ii = layerload("正在创建订单...");
    $.ajax({
            type : "POST",
            url : "ajax.php?act=createorder&r="+getrandnumber(),
            data : {"tradeno":tradeno,"gid":gid,"allprice":allprice,"price":price,"qq":qq,"type":type,"number":number},
            dataType : 'json',
            success : function(data) {
                     layer.close(ii);
                    if(data.code == 1){
                            layer.open({
                                title:"请核对订单信息",
                               content: html
                               ,btn: ['立即付款', '暂不付款']
                               ,yes: function(index){
                                  window.location.href='./other/submit.php?paynumber='+data.md5_tradeno;
                              }
                            });
                    }else{
                            layer.msg(data.msg);
                            return false;
                    }
            },
            error:function(data){
                     layer.close(ii);
                    layer.msg('系统错误！');
                    return false;
                    }
    })
 
}

function layerload(txt){
     var index = layer.load(1, {
                content: txt,
                shade: [0.4, '#393D49'],
                success: function(layero) {
                    layero.find('.layui-layer-content').css({
                    'padding-top': '40px',
                    'width': '100px',
                    'color':"#FFF",
                    'background-position-x': '16px'
                    });
            }
     })
     return index;
}