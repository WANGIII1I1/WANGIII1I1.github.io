<?php
$mydata = include ROOT . 'template/listshow/inc.php';


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
       <title id="bttt">订单提取 - <?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
        <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
        <meta name="description" content="<?php echo $conf['description']; ?>">
          <link rel="shortcut icon" type="image/x-icon" href="<?=$siteurl?>assets/imgs/favicon.ico" media="screen" />
        <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.7.2/css/amazeui.min.css" >
        <script src="<?= $siteurl ?>assets/layui/layui.js"></script>
        <script src="<?= $siteurl ?>assets/jquery/jquery.min.js"></script>
        <script src="<?= $siteurl ?>template/listshow/static/AmazeUI/js/amazeui.min.js"></script>
        <script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
        <link rel="stylesheet" href="<?= $siteurl ?>template/listshow/static/css/style.css" >
        <style type="text/css">
            .am-container{
                max-width: 1200px;
            }
            .am-topbar .am-text-ir {
                display: block;
                margin-right: 10px;
                height: 60px;
                width: 130px;
                background: url("<?= $siteurl ?>assets/imgs/logo.png") no-repeat left center;
                -webkit-background-size: 125px 24px;
                background-size: 125px 24px;
            }
            .am-topbar-inverse {
                background-color: #393D49;
            }

        </style>
    </head>
    <style>
    </style>
    <body>



        <header class="am-topbar am-topbar-inverse am-topbar-fixed-top">
            <div class="am-container">
                <h1 class="am-topbar-brand" style="margin:0 10px 0 0;">
                    <a href="./" class="am-text-ir" style="background-size: 130px 40px;"></a>
                </h1>

                <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse-2'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

                <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse-2">
                    <ul class="am-nav am-nav-pills am-topbar-nav">
                        <li><a href="./"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
                        <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes"><i class="am-icon-qq am-icon-fw"></i>联系客服</a></li>
                         <li><a onclick="addme()" href="#"><i class="am-icon-star am-icon-star"></i>收藏本站</a></li>
                        <?= $mydata['nav'] ?>
                    </ul>
                    <div class="am-topbar-right">
                        <a class="am-btn am-btn-success am-topbar-btn am-btn-sm" href="<?=$siteurl."index.php"?>" id="doc-prompt-toggle"><span class="am-icon-home am-icon-sm"></span>在线购买</a>
                    </div>
                </div>
            </div>
        </header>


        <div class="am-container">

           


            <div class="am-alert am-alert-secondary" data-am-alert style="margin-bottom:0px;background-color:#FFF;border-radius: 0px;margin-top: 20px">
                <button type="button" class="am-close">&times;</button>
                <p>
                    <span><span style="font-size:18px;color:#009900;">
                            <b>
                               发货公告：
                            </b></span>
                    </span> 
                </p>
                <p style="color:black;">
                    <?php echo $conf['dd_notice']; ?>
                </p>


            </div>

            

                <!--订单查询-->
                <div class="am-alert am-alert-secondary" data-am-alert style="margin-bottom:0px;background-color:#FFF;border-radius: 0px;">
                <button type="button" class="am-close">&times;</button>
                <br>
                <form action="?" method="GET">
                    <div class="am-input-group" style="margin-top: 5px">
                   <input type="text" class="am-form-field" value="<?=@$_REQUEST['no']?>" placeholder="订单号/联系方式/交易流水" name="no" required id="no">
                       
                        <span class="am-input-group-btn">
                            <button class="am-btn am-btn-default" type="submit" style="background-color: #29BB9C;color:#fff">搜索订单</button>
                        </span>
                    </div>
                </form>
                
                
                <?php
                if(!empty($_REQUEST['no'])){
                    $no = daddslashes($_REQUEST['no']); 
                     $no = _ayangw($no);
                    $sql = "select * from ayangw_km where out_trade_no = '$no' or trade_no = '$no' or rel = '$no' order by id desc";
                    $rs = $DB->query($sql);
                     
                    ?>
   <div style="margin-top:20px;color:green;font-size:30px">订单详细信息如下</div>                      
<table class="am-table am-table-bordered" style="background-color:#fff">
    <tr>
        <th>商品名称</th>
        <th>卡密</th>
        <th>时间</th>
    </tr>
     <?php
    while ($row = $DB->fetch($rs)){
        $grow = getgoods($row['gid']);
        ?>
        <tr>
            <th><?=$grow['gName']?></th>
            <th><?=$row['km']?></th>
            <th><?=$row['endTime']?></th>
        </tr>    
        <?php
    }
    ?>
      
       

</table>
                        
                        
                    <?php
                }
                ?>

            </div>
                <!--订单查询-->
  

            <div class="am-container" style="margin-top:20px">
                <div class="am-g">

                    <?= $mydata['links'] ?>
                </div>
            </div>

            <div class="tongji">

                <br><?= $conf['foot'] ?> </div>
        </div>

        <script>
        
        </script>
    </body>
</html>
<script>
function addme(){
    url = document.URL;
    title = $("#bttt").text(); 
    window.external.AddFavorite(url, title);
}
$(function(){
    var tradeno = $.cookie('tradeno');
    if($("#no").val() == ""){
        $("#no").val(tradeno);
    }
})
</script>
