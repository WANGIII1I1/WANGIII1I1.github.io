<?php
$mydata = include ROOT . 'template/listshow/inc.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?= $conf['title'] ?> - <?php echo $conf['ftitle']; ?></title>
        <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
        <meta name="description" content="<?php echo $conf['description']; ?>">
          <link rel="shortcut icon" type="image/x-icon" href="<?=$siteurl?>assets/imgs/favicon.ico" media="screen" />
        <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.7.2/css/amazeui.min.css" >
        <script src="<?= $siteurl ?>assets/layui/layui.js"></script>
        <script src="<?= $siteurl ?>assets/jquery/jquery.min.js"></script>
        <script src="<?= $siteurl ?>template/listshow/static/AmazeUI/js/amazeui.min.js"></script>
        <script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
        <link rel="stylesheet" href="<?= $siteurl ?>template/listshow/static/css/style.css" >
        <style type="text/css">
            .am-container{
                max-width: 1200px;
            }
            .am-topbar .am-text-ir {
                display: block;
                margin-right: 10px;
                height: 60px;
                width: 130px;
                background: url("<?= $siteurl ?>assets/imgs/logo.png") no-repeat left center;
                -webkit-background-size: 125px 24px;
                background-size: 125px 24px;
            }
            .am-topbar-inverse {
                background-color: #393D49;
            }

        </style>
    </head>
    <style>
    </style>
    <body>



        <header class="am-topbar am-topbar-inverse am-topbar-fixed-top">
            <div class="am-container">
                <h1 class="am-topbar-brand" style="margin:0 10px 0 0;">
                    <a href="./" class="am-text-ir" style="background-size: 130px 40px;"></a>
                </h1>

                <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse-2'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

                <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse-2">
                    <ul class="am-nav am-nav-pills am-topbar-nav">
                        <li><a href="./"><span class="am-icon-home am-icon-sm"></span>首页</a></li>
                        <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes"><i class="am-icon-qq am-icon-fw"></i>联系客服</a></li>
                        <li><a onclick="addme()" href="#"><i class="am-icon-star am-icon-star"></i>收藏本站</a></li>
 <?= $mydata['nav'] ?>
                    </ul>
                    <div class="am-topbar-right">
                        <a class="am-btn am-btn-success am-topbar-btn am-btn-sm" id="doc-prompt-toggle" href="<?=$siteurl."query.php"?>"><span class="am-icon-search"></span>订单查询</a>
                    </div>
                </div>
            </div>
        </header>


        <div class="am-container">

            <div class="am-show-portrait">
                <form action="<?=$siteurl."query.php"?>" method="POST">
                    <div class="am-input-group" style="margin-top: 5px">
                        <input type="text" class="am-form-field" value="<?=@$_REQUEST['no']?>" placeholder="订单号/联系方式/交易流水" name="no" required id="no">
                       
                        <span class="am-input-group-btn">
                            <button class="am-btn am-btn-default" type="submit" style="background-color: #29BB9C;color:#fff">订单查询</button>
                        </span>
                    </div>
                </form>
            </div>


            <div class="am-alert am-alert-secondary" data-am-alert style="margin-bottom:0px;background-color:#FFF;border-radius: 0px;">
                <button type="button" class="am-close">&times;</button>
                <p>
                    <span><span style="font-size:18px;color:#009900;">
                            <b>
                                网站公告：
                            </b></span>
                    </span> 
                </p>
                <p style="color:black;">
                    <?php echo $conf['notice1']; ?>
                </p>


            </div>

            <?php
            if (!empty($_GET['html'])) {
                $gid = intval($_GET['html']);
                $sql = "select * from ayangw_goods where id = " . $gid;
                $row = $DB->get_row($sql);
                $ycs = $DB->count("select count(id) from ayangw_order where sta =1 and gid = " . $row['id']);
                $kcount = $DB->count("select count(id) from ayangw_km where stat =0 and gid = " . $row['id']);
                ?>
                <div class="good-trade">
                    <form  method="POST"  style="padding:10px;margin-top: 20px;">
                        <div class="am-container">
                            <div class="am-g">

                                <div class="am-u-sm-12 am-u-md-4 am-u-lg-4 trade-goodimg am-u-end" style="padding:10px">

                                    <p><img src="<?= $siteurl . $row['imgs'] ?>" alt="" height="300px" width="100%"></p>


                                </div>
                                <div class="am-u-sm-12 am-u-md-8 am-u-lg-8  am-u-end" style="padding:10px">
                                    <!-- 网格开始 -->

                                    <input type="hidden" value="<?=$gid?>" name="goodid" id="goodid">
                                    <span id="goodsname"><?= $row['gName'] ?></span>
                                    <p class="trade-goodinfo">
                                        <span style="color:#6c6c6c">价格：</span>
                                        <span class="trade-price">¥<span id="price"><?= $row['price'] ?></span></span>

                                        <span style="float:right">
                                            <span style="color: #6C6C6C;">累积销量：</span>
                                            <span style="color:#6c6c6c;font-size:18px;"><?= $ycs ?></span>
                                        </span><br>   
                                        <span style="color:#6C6C6C">库存：<?= $kcount ?>件</span>

                                    </p>                    
                                  
                                    <span style="color:#6c6c6c;margin-left:10px">数量：</span>
                                    <input type="number" style="border: 0px;display: inline-block;border-bottom: 1px solid black;text-align: center;outline:medium;"  value="1" min="1" max="<?= $kcount ?>"  id="count" name="count"/>
                                    <br>
                                    <span style="color:#6c6c6c;margin-left:10px">联系QQ：</span>
                                    <input type="text" style="border: 0px;display: inline-block;border-bottom: 1px solid black;text-align: left;outline:medium;"  value=""  id="qq" name="qq"/>
                                    <br>

                                    
                                    <input type="hidden" value="<?= $kcount ?>" id="kucun">
                  
                                    <button type="button" class="am-btn am-btn-danger am-btn-xl"  id="paysubmit" style="margin-top:20px">
                                        <span class="am-icon-shopping-cart"></span>立即购买
                                    </button>


                                    <!-- 网格结束 -->
                                    
                                    <script>
                                $(function(){
                                    if($("#kucun").val()==0){
                                        $("#paysubmit").attr("class", 'am-btn am-btn-danger am-btn-xl am-disabled'); 
                                        $("#paysubmit").attr("disabled", true); 
                                        $("#paysubmit").html("库存不足");    
                                    }
                                    $("#paysubmit").click(function(){
                                        $("#pay_type").modal();
                                    })
                                });
                                function submit_pay(type){
                                         $("#pay_type").modal('close');
                                          
                                         var tradeno = gettradeno();
                                         
                                          var gid = $("#goodid").val();//商品ID
                                          var kucun = parseInt($("#kucun").val());//库存
                                          var count = parseInt($("#count").val());//购买数量
                                          var qq = $("#qq").val();
                                          
                                          var price = $("#price").text();//价格
                                          
                                          var allprice = (price*count).toFixed(2);
                                          var type = type;
                                          
                                          var payfs = $("#"+type).text();
                                          var gname = $("#goodsname").text();
                                          
                                          if(qq=="" || isNaN(qq) || qq.length <5){
                                               $("#ts_msg").text("亲,要输入正确的QQ号码哦~~");
                                               $('#tis').modal();
                                              return;
                                        }
                                        
                                          if(kucun<count){
                                              $("#ts_msg").text("购买数量大于库存数量");
                                               $('#tis').modal();
                                              return;
                                          }
                                          var html = "<span style='color:#000'>"
                                                +"订单编号："+tradeno
                                                +"<br>商品名称："+gname
                                                +"<br>商品单价："+price+"￥"
                                                +"<br>购买数量："+count
                                                +"<br>联系QQ："+qq
                                                +"<br>支付方式："+payfs
                                                +"<br>应付款：<font style='font-size:18px' color=red>"+allprice+"</font>￥"
                                                +"</span>";    
                                        $("#dd_msg").html(html);
                                      
                                        $('#my-confirm').modal({
                                            relatedTarget: this,
                                            onConfirm: function(options) {
                                               $.ajax({
                                                type : "POST",
                                                url : "ajax.php?act=createorder",
                                                data : {"tradeno":tradeno,"gid":gid,"allprice":allprice,"price":price,"qq":qq,"type":type,"number":count},
                                                dataType : 'json',
                                                success : function(data) {
                                                      
                                                        if(data.code == 1){
                                                             window.location.href='./other/submit.php?paynumber='+data.md5_tradeno;
                                                        }else{
                                                             alert(data.msg)
                                                                return false;
                                                        }
                                                },
                                                error:function(data){
                                                     
                                                        alert('系统错误！');
                                                        return false;
                                                        }
                                                })
                                            },
                                            // closeOnConfirm: false,
                                            onCancel: function() {
                                              
                                            }
                                          });
                                }
                                function gettradeno(){
                                    var timestamp =Date.parse(new Date());
                                    var rand = Math.floor(Math.random()*(99999-99+1)+99);
                                    var randnumber = timestamp+""+rand;
                                    $.cookie('tradeno',randnumber);
                                    return randnumber;
                                }
                                </script>
                                </div>
                            </div>
                        </div>

                    </form>
                    
  <div class="am-modal am-modal-confirm" tabindex="-1" id="my-confirm">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">订单核对</div>
    <div class="am-modal-bd" id="dd_msg" style=";text-align: left">
     
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn" data-am-modal-cancel>取消订单</span>
      <span class="am-modal-btn" data-am-modal-confirm>确定付款</span>
    </div>
  </div>
</div>
                    
<div class="am-modal am-modal-alert" tabindex="-1" id="tis">
  <div class="am-modal-dialog">
    
    <div class="am-modal-bd" id="ts_msg">
      ...
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">确定</span>
    </div>
  </div>
</div>
                    
<div class="am-modal-actions" id="pay_type">
  <div class="am-modal-actions-group">
    <ul class="am-list">
      <li class="am-modal-actions-header">请选择一种支付方式</li>
      <?php
      if($conf['switch_alipay']==1){
          ?>
       <li  class="am-modal-actions-success" onclick="submit_pay('alipay')">
          <a href="#"><span class="am-icon-cc-paypal"></span> <span id="alipay">支付宝</span></a>
      </li>
          <?php
      }
?>
         <?php
      if($conf['switch_wxpay']==1){
          ?>  
      <li class="am-modal-actions-danger" onclick="submit_pay('wxpay')">
        <a href="#"><i class="am-icon-wechat"></i> <span id="wxpay">微信支付</span></a>
      </li>
         <?php
      }
?>
            <?php
      if($conf['switch_qqpay']==1){
          ?>  
       <li class="am-modal-actions-info"  onclick="submit_pay('qqpay')">
        <a href="#"><i class="am-icon-qq"></i> <span id="qqpay">QQ钱包</span></a>
      </li>
         <?php
      }
?>
       <?php
      if($conf['switch_tenpay']==1){
          ?>  
       <li class="am-modal-actions-info"  onclick="submit_pay('tenpay')">
        <a href="#"><i class="am-icon-qq"></i> <span id="tenpay">财付通</span></a>
      </li>
          <?php
      }
?>
    </ul>
  </div>
  <div class="am-modal-actions-group">
    <button class="am-btn am-btn-secondary am-btn-block" data-am-modal-close>取消</button>
  </div>
</div>
                    

                    <div class="am-panel am-panel-default" style="border-radius:0px">
                        <div class="am-panel-hd">商品描述</div>
                        <div class="am-panel-bd">
                            <?= $row['gInfo'] ?>               </div>
                    </div>
                </div>


                <?php
            } else {
                ?>


                <!--商品-->
                <div class="goods">   
                    <!--电脑版商品-->
                    <div class="am-show-landscape">
                        <div class="am-container">
                            <div class="am-g">

                                <?php
                                $sql = "select * from ayangw_goods where state = 1 order by sotr desc";
                                $rs = $DB->query($sql);
                                while ($row = $DB->fetch($rs)) {
                                    $ycs = $DB->count("select count(id) from ayangw_order where sta =1 and gid = " . $row['id']);
                                    $kcount = $DB->count("select count(id) from ayangw_km where stat =0 and gid = " . $row['id']);
                                    ?>

                                    <div class="am-u-sm-6 am-u-md-4 am-u-lg-3 am-u-end" style="padding:2px">
                                        <div style="background-color:#fff;padding:8px">
                                            <a href="<?= $siteurl . "index.php?html=" . $row['id'] ?>">
                                                <div class="index-goodimg" >
                                                    <img src="<?= $siteurl . $row['imgs'] ?>" alt="" height="100%" width="100%" style="float:left">
                                                    <div style="position:absolute; z-index:2;right:10px;background-color:#F40;color:#fff;padding:5px">已售<?= $ycs ?>个</div>
                                                </div>
                                                <div class="pr-info"><span class="price">¥<?= $row['price'] ?></span>
                                                    <span class="pr-xl am-badge am-badge-danger" style="color:#fff">库存<?= $kcount ?>张</span>
                                                </div>
                                                <div class="index-goodname-xq" style="height:45px;color:#000"><p title="<?= $row['gName'] ?>"><?= $row['gName'] ?></p></div>
                                            </a>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                    <!--END 电脑版商品-->
                    <!--手机版商品-->
                    <div class="am-show-portrait">
                        <div class="am-container">
                            <div class="am-g">
                                <?php
                                $sql = "select * from ayangw_type where state = 1 order by sort desc";
                                $rs = $DB->query($sql);
                                while ($row = $DB->fetch($rs)) {
                                    ?>
                                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12" style="padding:2px">
                                        <div style="background-color: #393D49;color: #fff;padding: 10px;text-align: center"><?= $row['tName'] ?></div>
                                    </div>

                                    <?php
                                    $gsql = "select * from ayangw_goods where state = 1 and  tpId = " . $row['id'] . " order by sotr desc";
                                    $grs = $DB->query($gsql);
                                    while ($grow = $DB->fetch($grs)) {
                                        $ycs = $DB->count("select count(id) from ayangw_order where sta =1 and gid = " . $grow['id']);
                                        $kcount = $DB->count("select count(id) from ayangw_km where stat =0 and gid = " . $grow['id']);
                                        ?>
                                        <div class="am-u-sm-12 am-u-md-12 am-u-lg-12" style="margin-bottom: 5px;padding:2px">
                                            <div style="background-color: #fff;height: 80px">
                                                <div style="padding:5px">
                                                    <a href="<?= $siteurl . "index.php?html=" . $grow['id'] ?>" style="color: #000;">
                                                        <img class="am-radius" alt="140*140" src="<?= $siteurl . $grow['imgs'] ?>" width="70" height="70" style="float: left" />
                                                        <div class="am-text-truncate" style="margin-left: 15px;">
                                                            <span style="margin-left: 5px"><?= $grow['gName'] ?></span>
                                                            <br>
                                                            <div style="margin-top: 18px">
                                                                <span class="am-badge am-badge-danger am-radius" style="margin-left: 5px">库存(<?= $kcount ?>)</span>
                                                                <span class="am-badge am-badge-warning am-radius">销量(<?= $ycs ?>)</span>
                                                                <span style="color: #ff0000">
                                                                    <b>¥<?= $grow['price'] ?></b>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>    

                                        <?php
                                    }
                                    ?>

                                    <?php
                                }
                                ?>






                            </div>
                        </div>
                    </div>
                    <!--END 手机版商品-->
                </div>
                <!--end 商品-->
            <?php } ?>


            <div class="am-container" style="margin-top:20px">
                <div class="am-g">

                    <?= $mydata['links'] ?>
                </div>
            </div>

            <div class="tongji">

                <br><?= $conf['foot'] ?> </div>
        </div>

        <script>
        
        </script>
    </body>
</html><script>
function addme(){
    url = document.URL;
    title = $("#bttt").text(); 
    window.external.AddFavorite(url, title);
}
$(function(){
    var tradeno = $.cookie('tradeno');
    if($("#no").val() == ""){
        $("#no").val(tradeno);
    }
})
</script>
