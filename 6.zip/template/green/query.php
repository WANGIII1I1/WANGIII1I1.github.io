<html>
<head>
	<title id="bttt">订单提取 - <?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="stylesheet" href="<?= $siteurl ?>template/green/static/css/weui.min.css">
	<link rel="stylesheet" href="<?= $siteurl ?>template/green/static/css/jquery-weui.css">
	<link rel="stylesheet" href="<?= $siteurl ?>template/green/static/css/demos.css">
	<script src="<?= $siteurl ?>assets/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="<?= $siteurl ?>template/green/static/js/jquery-2.1.4.js"></script>
	<script type="text/javascript" src="<?= $siteurl ?>template/green/static/js/jquery-weui.js"></script>
	<script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
</head>

<body ontouchstart>
	<header class='demos-header' style="padding: 30px 0;padding-bottom: 0px;">
		<h1 class="demos-title">订单信息查询</h1>
	</header>
	<div class="weui-cells weui-cells_form">
		<div class="weui-cell weui-cell_vcode">
			<div class="weui-cell__bd">
				<input class="weui-input" type="text" placeholder="请输入订单号或联系方式查询" id="nos" value="<?=@$_REQUEST['no']?>" value="">
			</div>
			<div class="weui-cell__ft" style="padding: 10px;">
				<button class="weui-btn weui-btn_mini weui-btn_primary" onclick="querysub()">订单查询</button>
			</div>
		</div>
	</div>
	<?php
        if(!empty($_REQUEST['no'])){
            $no = daddslashes($_REQUEST['no']);
            $no = _safwl($no);
                
            if($conf['paypasstype']==1){
                //需要提取密码
                $paypass = _safwl($_REQUEST['paypass']);
                $sql = "select * from safwl_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1 and paypass='$paypass' order by id desc";
            }else{
                //不需要
                $sql = "select * from safwl_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1  order by id desc";
            }
            $row = $DB->get_row($sql);
            if($row){
        ?>	

	<div class="weui-form-preview">
		<div class="weui-form-preview__hd">
			<label class="weui-form-preview__label" style="font-size: 16px;bold;color: #000;">订单编号</label>
			<p class="weui-form-preview__value" style="font-size: 16px;"><?=$row['trade_no']?></p>
		</div>
		<div class="weui-form-preview__bd">
			<div class="weui-form-preview__item">
				<label class="weui-form-preview__label">商品名称</label>
				<span class="weui-form-preview__value">
				<?php   $grow = getgoods($row['gid']);  echo $grow['gName'];?></span>
			</div>

			<div class="weui-form-preview__item">
				<label class="weui-form-preview__label">金额</label>
				<span class="weui-form-preview__value"><?=$row['money']?>￥</span>
			</div>

			<div class="weui-form-preview__item">
				<label class="weui-form-preview__label">卡密</label>
				<span class="weui-form-preview__value">
					<?php
						$kmrs = $DB->query("select * from safwl_km where trade_no = '{$row['trade_no']}' and out_trade_no = '{$row['out_trade_no']}' and stat = 1");
                   		$kms = "";
                   		while ($kmrow = $DB->fetch($kmrs)){
                       		if($kms != "") $kms.=",";
                      		$kms .= $kmrow['km'];
                    	}
                    	echo $kms;
                    ?>
                </span>
			</div>

			<div class="weui-form-preview__item">
				<label class="weui-form-preview__label">付款时间</label>
				<span class="weui-form-preview__value"><?=$row['endTime']?></span>
			</div>
		</div>
	</div>
	<?php
        }else{
    ?>
    <div class="weui-loadmore weui-loadmore_line">
		<span class="weui-loadmore__tips">暂无数据</span>
	</div>
	
    <?php
        	}
        }
        ?>
	<div style="display: none;">
        <form action="" method="POST" id='queryfrm'>
            <input type="hidden" name="no" id='no' value="">
            <input type="hidden" name="paypass" id='paypass' value="">
        </form>
    </div>
	<div class="weui-btn-area">
		<a class="weui-btn weui-btn_primary" href="index.php" id="mysubmit">返回下单</a>
	</div>
</br></br></br></br></br>
<div style="text-align:center;">
	<span ><?= $conf['foot'] ?></span>
</div>

</div>
</body>
<script src="<?=$siteurl?>assets/layer/layer.js"></script>
<script>
	$(function(){
		var tradeno = $.cookie('tradeno');
		if($("#nos").val() == ""){
	       $("#nos").val(tradeno);
	    }
		var paypass = getCookie('paypass');
		if($("#paypass").val() == ""){
			$("#paypass").val(paypass);
		}
	})
	var needpass = <?=$conf['paypasstype']?>;

	function querysub(){
		var no = $("#nos").val();
		if(no == ""){
			layer.open({
				content: '请输入订单号或联系方式查询',
				btn: '我知道了'
			});
			return;
		}
		if(needpass == 1){
			layer.prompt({title: '请输入提取密码', formType: 2,value:""}, function(pass, index){
				layer.close(index);
				$("#no").val(no);
				$("#paypass").val(pass);
				$("#queryfrm").submit();
			});
		}else{
			$("#no").val(no);
			$("#queryfrm").submit();
		}

	}
	function getCookie(name){
		var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
		if(arr=document.cookie.match(reg))
			return unescape(arr[2]);
		else
			return null;
	}
</script>
</html>