<?php
$mydata = include ROOT . 'template/steam/inc.php';
function getPayType($str){
    if($str == "qqpay"){
        return "QQ钱包";
    }
    if($str == "tenpay"){
        return "财付通";
    }
    if($str == "alipay"){
        return "支付宝";
    }
    if($str == "wxpay"){
        return "微信";
    }
}
?>
<html>
<head><meta charset="utf-8">
       <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
  <title id="bttt">订单提取 - <?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
	<link rel="stylesheet" href="http://at.alicdn.com/t/font_687918_ikr0g02dgdp.css" type="text/css" media="all">
	<link rel="stylesheet" type="text/css" href="<?=$siteurl?>/template/steam/static/css/style.css">
	<link rel="stylesheet" type="text/css" media="screen and (max-width:767px)" href="<?=$siteurl?>/template/steam/static/css/phone.css">
	<link rel="stylesheet" type="text/css" media="screen and (min-width:767px)" href="<?=$siteurl?>/template/steam/static/css/windows.css">
	<style type="text/css">
   .id1130 .a3 .b1 .c1 .d3 .e2 {
      min-height: 40px;
      } 
  </style>
</head>
<body>
	<div>
		<div id="id1129" class="id1129">
			<div class='a1'>
				<div class='b1'>
                                    <A href="<?=$siteurl?>"><div class='c1'><?=$conf['title']?></div></A>
				</div>
			</div>
			<div class='a2'>
				<div class='b1'>
					<div class='c1'>
						<i class='d1'></i>
                                                <input type="text"placeholder="请输入订单号或联系方式查询"class='d2' id="nos" value="<?=@$_REQUEST['no']?>" />
                                                
                                                <div class='d3' onclick="querysub()">查 询</div>
					</div>
				</div>
			</div>
			<div class='a3'  style="min-height: 70%;">
                            <!--开始-->
                              <?php
        if(!empty($_REQUEST['no'])){
                $no = daddslashes($_REQUEST['no']);
                $no = _ayangw($no);
                    
                if($conf['paypasstype']==1){
                    //需要提取密码
                    $paypass = _ayangw($_REQUEST['paypass']);
                    $sql = "select * from ayangw_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1 and paypass='$paypass' order by id desc";
                }else{
                    //不需要
                    $sql = "select * from ayangw_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1  order by id desc";
                }
                 $row = $DB->get_row($sql);
                if($row){
            ?>
				<div class='b1' >
					<div class='c1'>
						<i class='d1'></i>
						<div class='d2'>
							<div class='e1'>
								<div class='f1'>搜索凭证：</div>
								<div class='f2'><?=$no?></div>
							</div>
						</div>
					</div>
                                     <div class='c4'>
						<div class='d1'>商品名称：</div>
                                                <div class='d2'><?php   $grow = getgoods($row['gid']);  echo $grow['gName'];?></div>
					</div>
					<div class='c2'>
						<div class='d1'>付款方式：</div>
						<div class='d2'><?=getPayType($row['type'])?></div>
						<div class='d3'>付款信息：</div>
						<div class='d4'>付款成功</div>
					</div>
					<div class='c3'>
						<div class='d1'>购买数量：</div>
                                                <div class='d2'><?=$row['number']?></div>
						<div class='d3'>订单金额：</div>
						<div class='d4'><?=$row['money']?>￥</div>
					</div>
                                    <div class='c4'>
						<div class='d1'>交易时间：</div>
						<div class='d2'><?=$row['endTime']?></div>
					</div>
					<div class='c4'>
						<div class='d1'>使用说明：</div>
						<div class='d2'><?=$mydata['km_sm']?></div>
					</div>
					<div class='c5'>
						<div class='d1'>卡密信息：</div>
						<div class='d2'>  <?php
                                                                     $kmrs = $DB->query("select * from ayangw_km where trade_no = '{$row['trade_no']}' and out_trade_no = '{$row['out_trade_no']}' and stat = 1");
                   $kms = "";
                   while ($kmrow = $DB->fetch($kmrs)){
                       if($kms != "") $kms.=",";
                      $kms .= $kmrow['km'];
                    }
                    echo $kms;
                                                                    ?></div>
					</div>
				</div>
                             <?php
        }  
        }else{
            echo '无订单记录';
        }
        
        ?>
                            <!--结束-->
			</div>
                    <div style="margin-top: 20px;font-size: 16px;padding-top: 10px;color:black"><?=$conf['foot']?></div>
		</div>
         
		<div id="id1130" class="id1130">
			<div   class='a1'>
		<div   class='b1'>
			<div   class='c1'><?=$conf['title']?></div>
                        <a href="<?=$siteurl?>"><div   class='c2'>首页</div></a>
		</div>
	</div>
			<div class='a2'>
				<div class='b1'>
					<div class='c1'>
						<i class='d1'></i>
                                                <input type="text"placeholder="请输入订单号或联系方式查询"class='d2' id='pc_nos' value="<?=@$_REQUEST['no']?>" />
						
                                                <div class='d3' style="cursor: pointer"  onclick="querysub()">查 询</div>
					</div>
				</div>
			</div>
                    <div class='a3' style="min-height: 70%;">
                            
                            <!-- 开始 -->
                             <?php
        if(!empty($_REQUEST['no'])){
                $no = daddslashes($_REQUEST['no']);
                $no = _ayangw($no);
                    
                if($conf['paypasstype']==1){
                    //需要提取密码
                    $paypass = _ayangw($_REQUEST['paypass']);
                    $sql = "select * from ayangw_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1 and paypass='$paypass' order by id desc";
                }else{
                    //不需要
                    $sql = "select * from ayangw_order where (out_trade_no = '$no' or trade_no = '$no' or md5_trade_no ='$no' or rel = '$no') and sta = 1  order by id desc";
                }
                 $row = $DB->get_row($sql);
                if($row){
            ?>
				<div class='b1'>
					<div class='c1'>
						<div class='d1'>
							<div class='e1'>搜索凭证：</div>
							<div class='e2'><?=$no?></div>
						</div>
						<div class='d2'>
							<div class='e1'>付款方式：</div>
							<div class='e2'><?=getPayType($row['type'])?></div>
							<div class='e3'>付款信息：</div>
							<div class='e4'>付款成功</div>
							<div class='e5'>交易时间：</div>
							<div class='e6'><?=$row['endTime']?></div></div>
							<div class='d3'>
								<div class='e1'>卡密信息：</div>
                                                                <div class='e2' id="ckms">
                                                                    <?php
                                                                     $kmrs = $DB->query("select * from ayangw_km where trade_no = '{$row['trade_no']}' and out_trade_no = '{$row['out_trade_no']}' and stat = 1");
                   $kms = "";
                   while ($kmrow = $DB->fetch($kmrs)){
                       if($kms != "") $kms.=",";
                      $kms .= $kmrow['km'];
                    }
                    echo $kms;
                                                                    ?>
                                                                </div>
							</div>
						</div>
						<div class='c2'>
							<div class='d1'>
								<div class='e1'>金额：</div>
                                                                <div class='e2' style="color:Red"><?=$row['money']?>￥</div>
							</div>
						</div>
						<div class='c3'>
							<div class='d1'>
                                                            <a href="http://wpa.qq.com/msgrd?v=1&uin=<?php echo $conf['zzqq']; ?>&site=<?= $siteurl ?>&menu=yes'" target="_blank"><div class='e1'>联系卖家</div></a>
							</div>
                                                    <div class='d2' style="cursor: pointer" onclick="copykm('ckms')">
								<div class='e1'>复制卡密信息</div>
							</div>
						</div>
					</div>
                            
                            
					<div class='b2'>
						<div class='c1'>
							<div class='d1'>使用说明：</div>
							<div class='d2'><?=$mydata['km_sm']?></div>
						</div>
					</div>
       <?php
        }  
        }
        ?>
                             <!-- 结束 -->
				</div>
                       <div style="margin-top: 20px;font-size: 16px;padding-top: 10px;color:black;text-align: center"><?=$conf['foot']?></div>
			</div>
		</div>
	</div>
        <div style="display: none;">
            <form action="" method="POST" id='queryfrm'>
                <input type="hidden" name="no" id='no'>
                <input type="hidden" name="paypass" id='paypass'>
            </form>
        </div>
           <?php
    if($conf['payapi'] == 5){
        echo '<div style="display: none"><img src="/codepay/codepay_cron.php" width="1" height="1"></div>';
    }
    ?>
 
  <script src="<?=$siteurl?>assets/jquery/jquery.min.js"></script>
        <script src="<?=$siteurl?>assets/layer/layer.js"></script>
         <script>
  $(function(){
    var tradeno =getCookie('tradeno');
    if($("#nos").val() == ""){
        $("#nos").val(tradeno);
    }
     if($("#pc_nos").val() == ""){
        $("#pc_nos").val(tradeno);
    }
    var paypass = getCookie('paypass');
    if($("#paypass").val() == ""){
        $("#paypass").val(paypass);
    }
})
         var needpass = <?=$conf['paypasstype']?>;
         function querysub(){
             var no = $("#nos").val();
             if(no == ""){
                 no = $("#pc_nos").val();
             }
             if(needpass == 1){
                 layer.prompt({title: '请输入提取密码', formType: 2,value:""}, function(pass, index){
                    layer.close(index);
                    $("#no").val(no);
                    $("#paypass").val(pass);
                    $("#queryfrm").submit();
                  });
             }else{
                  $("#no").val(no);
                   $("#queryfrm").submit();
             }
                
         }
         function getCookie(name)
{
var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
if(arr=document.cookie.match(reg))
return unescape(arr[2]);
else
return null;
}
  currentLang = navigator.language;   //判断除IE外其他浏览器使用语言
        if(!currentLang){//判断IE浏览器使用语言
            currentLang = navigator.browserLanguage;
        }
        var browser={
            versions:function(){
                var u = navigator.userAgent, app = navigator.appVersion;
                return {
                    trident: u.indexOf('Trident') > -1, //IE内核
                    presto: u.indexOf('Presto') > -1, //opera内核
                    webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                    gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
                    mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                    ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                    android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
                    iPhone: u.indexOf('iPhone') > -1 , //是否为iPhone或者QQHD浏览器
                    iPad: u.indexOf('iPad') > -1, //是否iPad
                    webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
                };
            }(),
            language:(navigator.browserLanguage || navigator.language).toLowerCase()
        }
function copykm(id){
    if(browser.versions.ios ){
        alert("苹果系统暂时不支持一键复制！");
    }else{
        var Url2=document.getElementById(id).innerText;
        var oInput = document.createElement('input');
        oInput.value = Url2;
        document.body.appendChild(oInput);
        oInput.select(); // 选择对象
        document.execCommand("Copy"); // 执行浏览器复制命令
        oInput.className = 'oInput';
        oInput.style.display='none';
        layer.alert('复制成功!');
    }
}
         </script>
</body>
</html>