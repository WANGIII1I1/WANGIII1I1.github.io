<?php

define('SYSTEM_ROOT_E', dirname(__FILE__) . '/');
include '../ayangw/common.php';


ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';
foreach ($_POST AS $key => $val) {
    if ($val == '') continue;
    if ($key != 'sign') {
        if ($sign != '') {
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //拼接为url参数形式
        $urls .= "$key=" . urlencode($val); //拼接为url参数形式
    }
}
if (!$_POST['pay_no'] || md5($sign . $conf['epay_key']) != $_POST['sign']) { //不合法的数据 KEY密钥为你的密钥
    exit('fail | pay_no：'.$_POST['pay_no']."|sign:".$_POST['sign']."|md5:".md5($sign . $conf['epay_key']));
} else { //合法的数据
    $md5_trade_no = $_POST['param'];
    $sql = "SELECT * FROM ayangw_order WHERE md5_trade_no='{$md5_trade_no}' limit 1";
    $row = $DB->get_row($sql);
    if($row['sta'] != 0){
       wsyslog("mcallbackprocess,订单已被处理,","状态：(".$row['sta'].")：".$md5_trade_no);
       exit('success');
    }
    if(mmcallbackprocess()){
         exit('success');
    }else{
         exit('fail');
    }
   
}
function mmcallbackprocess(){
    $trade_no = $_POST['pay_no'];
    $md5_trade_no = $_POST['param'];
    $sql = "SELECT * FROM ayangw_order WHERE md5_trade_no='{$md5_trade_no}' limit 1";
    global $DB,$conf;
    $row = $DB->get_row($sql);
    if(!$row){
        wsyslog("mcallbackprocess,处理失败","订单不存在！");
        return false;
    }
     if($row['sta'] != 0){
        wsyslog("mcallbackprocess,处理失败","订单已被处理,状态：(".$row['sta'].")：".$out_trade_no);
        return true;
    }
    $number = $row['number'];
    $money = $row['money'];
    $qq = $row['rel'];
    $out_trade_no = $row['out_trade_no'];
    $goodsrow = getgoods($row['gid']);
    if(!$goodsrow || $money != round($goodsrow['price']*$number,2)){
         wsyslog("mcallbackprocess,处理失败","价格计算失败(系统价格：".$money."/计算价格".(round($goodsrow['price']*$number,2)).")：".$out_trade_no);
        return false;
    }
    $sql = "update ayangw_order set sta = 1, trade_no = '{$trade_no}' ,endTime = now() where id = {$row['id']} and out_trade_no = '{$out_trade_no}'";
    if($DB->query($sql)){
        $kmsql = "select * from ayangw_km where  gid = {$row['gid']} and stat = 0 limit $number";
        $kmrs = $DB->query($kmsql);
        $kmlist = "";
        $ok = 0;
        while ($kmrow = $DB->fetch($kmrs)){
            $kmlist!=""?$kmlist=$kmlist.",":"";
            $kmlist .= $kmrow['km'];
            if($DB->query("update ayangw_km set endTime = now(),out_trade_no = '{$out_trade_no}',trade_no='{$trade_no}',rel ='{$row['rel']}',stat = 1 where gid = {$row['gid']} and stat = 0 and id = ".$kmrow['id'])){
                $ok++; 
            }
        }
        if($conf['sendemail']){
            if(sendemail($qq."@qq.com","您已成功购买卡密,订单编号：".$out_trade_no.",您的卡密为：[  ".$kmlist." ]")){
                wsyslog("邮箱提醒成功","订单编号：".$out_trade_no.",已发送到：".$qq."@qq.com");
            }else{
                 wsyslog("邮箱提醒失败","订单编号：".$out_trade_no.",邮箱：".$qq."@qq.com");
            }
        }
         wsyslog("mcallbackprocess,交易成功","订单编号：".$md5_trade_no.";数量：".$number.";成功提取数量：".$ok."");
         return true;

    }else{
        wsyslog("mcallbackprocess,处理失败","修改订单状态失败：".$out_trade_no);
        return false;
    }
    
}
?>